'use strict';

/* Controllers */

angular.module('app')
  .controller('AppCtrl', ['$scope', '$rootScope', '$translate', '$localStorage', '$window', '$http', '$interval', 
    function(              $scope,   $rootScope,   $translate,   $localStorage,   $window, $http, $interval ) {
      // add 'ie' classes to html
      var isIE = !!navigator.userAgent.match(/MSIE/i);
      isIE && angular.element($window.document.body).addClass('ie');
      isSmartDevice( $window ) && angular.element($window.document.body).addClass('smart');


      // config
      $rootScope.app = {
        name: 'Tinguis',
        version: '2.0.1',
        // for chart colors
        color: {
          primary: '#7266ba',
          info:    '#23b7e5',
          success: '#006A44',
          warning: '#fad733',
          danger:  '#f05050',
          light:   '#e8eff0',
          dark:    '#3a3f51',
          black:   '#1c2b36'
        },
        settings: {
          themeID: 11,
          navbarHeaderColor: 'bg-success',
          navbarCollapseColor: 'bg-white-only',
          asideColor: 'bg-dark',
          headerFixed: false,
          asideFixed: false,
          asideFolded: true,
          asideDock: true,
          container: false
        },
        user:{}
      }

      // save settings to local storage
      if ( angular.isDefined($localStorage.settings) ) {
        $scope.app.settings = $localStorage.settings;
      } else {
        $localStorage.settings = $scope.app.settings;
      }
      $scope.$watch('app.settings', function(){
        // if( $scope.app.settings.asideDock  &&  $scope.app.settings.asideFixed ){
        //   // aside dock and fixed must set the header fixed.
        //   $scope.app.settings.headerFixed = true;
        // }
        // save to local storage
        $localStorage.settings = $scope.app.settings;
      }, true);

      // angular translate
      $scope.lang = { isopen: false };
      $scope.langs = {pt_BR:'Português do Brasil', en:'English', de_DE:'German', it_IT:'Italian'};
      $scope.selectLang = $scope.langs[$translate.proposedLanguage()] || "Português do Brasil";
      $scope.setLang = function(langKey, $event) {
        // set the current lang
        $scope.selectLang = $scope.langs[langKey];
        // You can change the language during runtime
        $translate.use(langKey);
        $scope.lang.isopen = !$scope.lang.isopen;
      };

      $scope.app.settings.navbarHeaderColor='bg-info dker'; 
      $scope.app.settings.navbarCollapseColor='bg-info dker'; 
      $scope.app.settings.asideColor='bg-light dker b-r';    

      function isSmartDevice( $window ){
          // Adapted from http://www.detectmobilebrowsers.com
          var ua = $window['navigator']['userAgent'] || $window['navigator']['vendor'] || $window['opera'];
          // Checks for iOs, Android, Blackberry, Opera Mini, and Windows mobile devices
          return (/iPhone|iPod|iPad|Silk|Android|BlackBerry|Opera Mini|IEMobile/).test(ua);
      }

      // Verifica a sessao a cada 31 minutos, ela expira em 30 em casos de ociosidade
      $interval(function(){
        $http.post('api/utils/session.php', {check:1}).then(function(){
          // o redirecionamento sera realizado pelo httpR'esponseInterceptor
          console.info('Verifica sessão!'
        )});
      }, 180100);

  }]);

  app.factory('focus', function($timeout, $window) {
    return function(id) {
      // timeout makes sure that it is invoked after any other event has been triggered.
      // e.g. click events that need to run before the focus or
      // inputs elements that are in a disabled state but are enabled when those events
      // are triggered.
      $timeout(function() {
        var element = $window.document.getElementById(id);
        if(element)
          element.focus();
      });
    };
  });
  
  app.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push('httpResponseInterceptor');
  }]);
  
  app.factory('httpResponseInterceptor', ['$q', '$location', function($q, $location){
    return {
      response:function(response){
        if(response.data.code == 1500){
          console.info("Redicionamento automático por sessão expirada.")
          $location.path('/acesso/signin/1500');
        }
        return response;
      }
    };
  }]);

app.filter('dateFormat', function(){
    var date = "";
    return function(input, formatFrom, formatTo){
      if( input instanceof Date && formatFrom === false && typeof formatTo == "string"){
        date = moment(input).locale('pt-br').format(formatTo);
      }else if( typeof input == "string" && typeof formatFrom == "string" && formatTo === "date" ){
        date = moment(input, formatFrom).toDate();
      }else if( typeof input == "string" && typeof formatFrom == "string" && typeof formatTo == "string" ){
        date = moment(input, formatFrom).locale('pt-br').format(formatTo);
      }
      return date;
    };
});

app.filter('placaFormat', function(){
    return function(input){
      return input.replace(/(.*)(\d{4})/,"$1-$2");
    };
});

app.filter('fromNow', function(){
    return function(input, format){
      return moment(input, format).locale('pt-br').fromNow();
    };
});


app.run(['$rootScope', '$document', '$timeout', function ($rootScope, $document, $timeout) {

    var bindingForAppleDevice = function () {
      $document.bind("keydown", function (event) {
        if (event.keyCode === 20) { setCapsLockOn(true); }
      });

      $document.bind("keyup", function (event) {
        if (event.keyCode === 20) { setCapsLockOn(false); }
      });

      $document.bind("keypress", function (event) {
        var code = event.charCode || event.keyCode;
        var shift = event.shiftKey;

        if (code > 96 && code < 123) { setCapsLockOn(false); }
        if (code > 64 && code < 91 && !shift) { setCapsLockOn(true); }
      });
    };

    var bindingForOthersDevices = function () {
      var isKeyPressed = true;

      $document.bind("keydown", function (event) {
        if (!isKeyPressed && event.keyCode === 20) {
          isKeyPressed = true;
          if ($rootScope.isCapsLockOn != null) { setCapsLockOn(!$rootScope.isCapsLockOn); }
        }
      });

      $document.bind("keyup", function (event) {
        if (event.keyCode === 20) { isKeyPressed = false; }
      });

      $document.bind("keypress", function (event) {
        var code = event.charCode || event.keyCode;
        var shift = event.shiftKey;

        if (code > 96 && code < 123) { setCapsLockOn(shift); }
        if (code > 64 && code < 91) { setCapsLockOn(!shift); }
      });
    };

    if (/Mac|iPad|iPhone|iPod/.test(navigator.platform)) {
      bindingForAppleDevice();
    } else {
      bindingForOthersDevices();
    }

    var setCapsLockOn = function (isOn) {
      $timeout(function () {
        $rootScope.isCapsLockOn = isOn;
      });
    };

  }]);
'use strict';

/**
 * Config for the router
 */
angular.module('app')
  .run(
    [          '$rootScope', '$state', '$stateParams',
      function ($rootScope,   $state,   $stateParams) {
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;        
      }
    ]
  )
  .config(
    [          '$stateProvider', '$urlRouterProvider', 'JQ_CONFIG', 
      function ($stateProvider,   $urlRouterProvider, JQ_CONFIG) {
          
          $urlRouterProvider.otherwise('/acesso/signin/1');

          $stateProvider
              .state('app', {
                  abstract: true,
                  url: '/app',
                  templateUrl: 'tpl/app.html'
              })
              .state('app.login', {
                  url: '/login',
                  templateUrl: 'modules/usuario/login.html',
                  resolve: {
                    deps: ['$ocLazyLoad',
                      function( $ocLazyLoad ){
                        return $ocLazyLoad.load(['modules/usuario/usuario.js']);
                    }]
                  }
              })              
              .state('app.usuario', {
                  url: '/usuario',
                  templateUrl: 'modules/usuario/usuario.html',
                  resolve: {
                    deps: ['$ocLazyLoad',
                      function( $ocLazyLoad ){
                        return $ocLazyLoad.load(['modules/usuario/usuario.js', 'modules/utils/directives.js']);
                    }]
                  }
              })
              .state('app.unidade', {
                  url: '/unidade',
                  templateUrl: 'modules/unidade/unidade.html',
                  resolve: {
                    deps: ['$ocLazyLoad',
                      function( $ocLazyLoad ){
                        return $ocLazyLoad.load(['modules/unidade/unidade.js']);
                    }]
                  }
              })
              .state('app.veiculo', {
                  url: '/veiculo',
                  templateUrl: 'modules/veiculo/veiculo.html',
                  resolve: {
                    deps: ['$ocLazyLoad',
                      function( $ocLazyLoad ){
                        return $ocLazyLoad.load(['modules/veiculo/veiculo.js']);
                    }]
                  }
              })
              .state('app.moradores', {
                  url: '/moradores',
                  templateUrl: 'modules/moradores/moradores.html',
                  resolve: {
                    deps: ['$ocLazyLoad',
                      function( $ocLazyLoad ){
                        return $ocLazyLoad.load(['modules/moradores/cpf.min.js', 'modules/moradores/ngCpfCnpj.js', 'modules/moradores/moradores.js']);
                    }]
                  }
              })
              .state('lockme', {
                  url: '/lockme',
                  templateUrl: 'modules/acesso/lockme.html'
              })
              .state('acesso', {
                  url: '/acesso',
                  template: '<div ui-view class="fade-in-right-big smooth"></div>'
              })
              .state('acesso.signin', {
                  url: '/signin/:errorCode',
                  templateUrl: 'modules/acesso/signin.html',
                  resolve: {
                      deps: ['uiLoad',
                        function( uiLoad ){
                          return uiLoad.load( ['modules/acesso/acesso.js'] );
                      }]
                  }
              })
              .state('acesso.signup', {
                  url: '/signup/:errorCode?',
                  templateUrl: 'modules/acesso/signup.html',
                  resolve: {
                      deps: ['uiLoad',
                        function( uiLoad ){
                          return uiLoad.load( ['modules/acesso/acesso.js'] );
                      }]
                  }
              })
      }
    ]
  );

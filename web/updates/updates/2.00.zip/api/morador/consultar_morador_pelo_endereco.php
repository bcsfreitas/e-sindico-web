<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();
if( !isset($_POST['rua']) && !isset($_POST['unidade']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['rua']) && !isset($_POST['unidade'])){
    $json['code'] = 8001;
    $json['error'] = "A rua ou unidade não foi definida";
}else{
    try {
        $rua = $_POST['rua'];
        $unidade = $_POST['unidade'];

        $conn = new PDO("mysql:host=$servername;dbname=$db", 
            $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT morador.nome, morador.celular, morador.id, morador.id as unidade_id from unidades 
INNER JOIN morador ON unidades.id = morador.id_unidade
WHERE rua=:rua and numero=:unidade");
        $r = $stmt->execute(array(':rua' => $rua, ':unidade'=>$unidade));

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 

        // $results = array_map(function($r) {
        //    $r['descicao_modelo'] = utf8_encode( $r['descicao_modelo'] );
        //    return $r;
        // }, $results);

        $json['results'] = $results;    
    }catch(PDOException $e){
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
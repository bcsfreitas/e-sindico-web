<?php
require "../utils/config_db.php";
require "../utils/log_register.php";
$json = array();

// for angular JSON params
if( !isset($_POST['cpf']) OR !isset($_POST['senha']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}

if( !isset($_POST['cpf']) OR !isset($_POST['senha']) ){
    $json['code'] = 1150;
    $json['error'] = "O usuário ou a senha não foram definidos.";
}else{
    $cpf = $_POST['cpf'];
    $senha = md5($_POST['senha']);
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT id, cpf, nome, senha FROM usuarios WHERE cpf=:cpf AND senha=:senha");
        $r = $stmt->execute(array(':cpf' => $cpf, ':senha' => $senha));

        if($r === false){
            $json['error'] = $stmt->errorInfo();
        }

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 
        $results = array_map(function($r) {
             $r['nome'] = utf8_encode( $r['nome'] );
             return $r;
        }, $results);
        if(count($results)==0){
            $json['code'] = 1000;
            $json['error'] = "Não existe informações para este CPF e senha.";
            logger('Tentativa de login inválida', $cpf);
        }else{
            // Grava log da autenticação
            logger('Logou no sistema', $cpf);
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['CREATED'] = time();
            $_SESSION['USER'] = $results[0];
            $json['results'] = $results;
        }
    }catch(PDOException $e){
        $json['code'] = 1001;
        $json['error'] = $e->getMessage();
    }
}

echo json_encode($json);
$conn = null;
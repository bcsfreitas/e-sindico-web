<?php
require "../utils/session.php";
require "../utils/config_db.php";


$json = array();

if( $OK_SESSION == 0){
    $json['session']['user'] = $_SESSION['USER'];
    $json['session']['created'] = $_SESSION['CREATED'];
    $_SESSION['CREATED'] = time();

    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("INSERT INTO `dbcondiminio`.`log` (`id`, `usuario`, `mensagem`, `codigo`, `data`) VALUES (NULL, :cpf, 'Renovação de sessão', 2020, CURRENT_TIMESTAMP);");
    $stmt->execute( array(':cpf' => $json['session']['user']['cpf'] ) );

}else if($OK_SESSION == 1){
    $json['codigo'] = 1200;
    $json['error'] = "Não existe sessão aberta, tente efetuar login no sistema.";
}else if($OK_SESSION == 2){
    $json['codigo'] = 1500;
    $json['error'] = "Sua sessão expirou.";
}

echo json_encode($json);
$conn = null;
<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();
if( !isset($_POST['placa']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['placa']) ){
    $json['code'] = 6001;
    $json['error'] = "A placa do veículo não foi definida";
}else{
    try {
        $placa = $_POST['placa'];
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT v.placa, v.modelo, v.ano, v.modelo_ano, v.municipio, v.uf, vv.data_visita, vv.data_saida FROM `visita_veiculo` as vv INNER JOIN veiculo as v ON v.placa = vv.placa WHERE v.placa=:placa ORDER BY data_visita DESC LIMIT 3");
        $r = $stmt->execute(array(':placa' => $placa));

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 

        // $results = array_map(function($r) {
        //    $r['descicao_modelo'] = utf8_encode( $r['descicao_modelo'] );
        //    return $r;
        // }, $results);

        $json['results'] = $results;    
    }catch(PDOException $e){
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
<?php
require "../utils/session.php";
require "../utils/config_db.php";
require "../utils/log_register.php";

$json = array();
if( !isset($_POST['placa']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['placa']) 
    && !isset($_POST['marca']) 
    && !isset($_POST['modelo']) 
    && !isset($_POST['cor']) 
    && !isset($_POST['chassi']) 
    && !isset($_POST['municipio'])
    && !isset($_POST['uf']) 
    && !isset($_POST['ano']) 
    && !isset($_POST['modelo_ano'])
    && !isset($_POST['situacao'])
    && !isset($_POST['codigoSituacao'])   
 ){
    $json['code'] = 9002;
    $json['error'] = "Parâmetros incompletos";
}else{

    if(isset($_POST['placa'])){
        $placa = $_POST['placa'];
    }else{
        $placa = null;
    }
    if(isset($_POST['marca'])){
        $marca = $_POST['marca'];
    }else{
        $marca = null;
    }
    if(isset($_POST['modelo'])){
        $modelo = $_POST['modelo'];
    }else{
        $modelo = null;
    }
    if(isset($_POST['cor'])){
        $cor = $_POST['cor'];
    }else{
        $cor = null;
    }
    if(isset($_POST['chassi'])){
        $chassi = $_POST['chassi'];
    }else{
        $chassi = null;
    }
    if(isset($_POST['municipio'])){
        $municipio = $_POST['municipio'];
    }else{
        $municipio = null;
    }
    if(isset($_POST['uf'])){
        $uf = $_POST['uf'];
    }else{
        $uf = null;
    }
    if(isset($_POST['ano'])){
        $ano = $_POST['ano'];
    }else{
        $ano = null;
    }
    if(isset($_POST['modelo_ano'])){
        $anoModelo = $_POST['modelo_ano'];
    }else{
        $anoModelo = null;
    }
    if(isset($_POST['situacao'])){
        $situacao = $_POST['situacao'];
    }else{
        $situacao = null;
    }
    if(isset($_POST['codigoSituacao'])){
        $codigoSituacao = $_POST['codigoSituacao'];
    }else{
        $codigoSituacao = null;
    }

    try {
        $pdo = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $s = $pdo->prepare("INSERT INTO `dbcondiminio`.`veiculo` (`placa`, `marca`, `modelo`, `cor`, `chassi_final`, `ano`, `modelo_ano`, `municipio`, `uf`, `renavam`, `situacao`, `codigoSituacao`, `data_cadastro`) VALUES (:placa, :marca, :modelo, :cor, :chassi, :ano, :anomodelo, :municipio, :uf, NULL, :situacao, :codigoSituacao, CURRENT_TIMESTAMP);"); 
        $s->bindParam(':placa', $placa, PDO::PARAM_STR, 200); 
        $s->bindParam(':marca', $marca, PDO::PARAM_STR, 200); 
        $s->bindParam(':modelo', $modelo, PDO::PARAM_STR, 200); 
        $s->bindParam(':cor', $cor, PDO::PARAM_STR, 200); 
        $s->bindParam(':chassi', $chassi, PDO::PARAM_STR, 200); 
        $s->bindParam(':ano', $ano, PDO::PARAM_STR, 200); 
        $s->bindParam(':anomodelo', $anoModelo, PDO::PARAM_STR, 200);
        $s->bindParam(':municipio', $municipio, PDO::PARAM_STR, 200);
        $s->bindParam(':uf', $uf, PDO::PARAM_STR, 200);
        $s->bindParam(':situacao', $situacao, PDO::PARAM_STR, 100);
        $s->bindParam(':codigoSituacao', $codigoSituacao, PDO::PARAM_STR, 10);
        $s->execute();
        $json['success'] = "Veículo registrado";
        logger("Veículo adicionado: placa: ".$placa, null);
    }catch(PDOException $e){
        $json['code'] = $pdo->errorCode();
        $json['info'] = $pdo->errorInfo();
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
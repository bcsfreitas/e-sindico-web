<?php
  // Desenvolvido Para fins EDUCATIVOS.
  // Criado em 12/11/2014
  // Contato: putyoe@hotmail.com
  // Editado em 22/06/2015
  // Contato: hersonrodrigues@gmail.com
  $json = array();
  if( !isset($_REQUEST['placa']) ){
    $_REQUEST = json_decode(file_get_contents('php://input'),true);
  }
  if( !isset($_REQUEST['placa']) ){
    $json['code'] = 9002;
    $json['error'] = "A placa do veículo não foi definida";
  }else{
    $placa   = $_REQUEST['placa'];
    $token = hash_hmac('sha1', $placa, 'shienshenlhq');
    $request = '<?xml version="1.0" encoding="utf-8" standalone="yes" ?><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" ><soap:Header><dispositivo>GT-S1312L</dispositivo><nomeSO>Android</nomeSO><versaoAplicativo>1.1.1</versaoAplicativo><versaoSO>4.1.4</versaoSO><aplicativo>aplicativo</aplicativo><ip>177.206.169.90</ip><token>'.$token.'</token><latitude>-3.6770324</latitude><longitude>-38.6791411</longitude></soap:Header><soap:Body><webs:getStatus xmlns:webs="http://soap.ws.placa.service.sinesp.serpro.gov.br/"><placa>'.$placa.'</placa></webs:getStatus></soap:Body></soap:Envelope>';
    $header = array(
      "Content-type: application/x-www-form-urlencoded; charset=UTF-8",
      "Accept: text/plain, */*; q=0.01",
      "Cache-Control: no-cache",
      "Pragma: no-cache",
      "x-wap-profile: http://wap.samsungmobile.com/uaprof/GT-S7562.xml",
      "Content-length: ".strlen($request),
      "User-Agent: Mozilla/5.0 (Linux; U; Android 4.1.4; pt-br; GT-S1162L Build/IMM76I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
    );
    $url = "http://sinespcidadao.sinesp.gov.br/sinesp-cidadao/ConsultaPlacaNovo27032014";
    $soap_do = curl_init();
    curl_setopt($soap_do, CURLOPT_URL, $url);
    curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 120);
    curl_setopt($soap_do, CURLOPT_TIMEOUT,        120);
    curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($soap_do, CURLOPT_POST,           true );
    curl_setopt($soap_do, CURLOPT_POSTFIELDS,     $request);
    curl_setopt($soap_do, CURLOPT_HTTPHEADER,     $header);
    $output = curl_exec($soap_do);
    $json = array();
    if($output === false){
      $err = 'Curl erro: ' . curl_error($soap_do);
      $json['code'] = 9876;
      $json['error'] = $err;
    }else{  

      if(md5($output) == "f1f722896b4432e7e75032c12a7c5de1"){
        $json['code'] = 890;
        $json['error'] = "Não foi ncontrado nenhum veículo com a placa ".$placa.".";
      }else{

        try{
          preg_match('/<cor>(.*?)<\/cor>/', $output, $cor);
          $cor = $cor[1];
        }catch(Exception $e){
          $cor = "INDEFINIDA";
        }

        try{
          preg_match('/<uf>(.*?)<\/uf>/', $output, $uf);
          $uf = $uf[1];
        }catch(Exception $e){
          $uf = "XX";
        }
        
        try{
          preg_match('/<ano>(.*?)<\/ano>/', $output, $ano);
          $ano = $ano[1];
        }catch(Exception $e){
          $ano = "0000";
        }

        try{
          preg_match('/<chassi>(.*?)<\/chassi>/', $output, $chassi);
          $chassi = $chassi[1];
        }catch(Exception $e){
          $chassi = "XXXXX";
        }
        
        try{
          preg_match('/<placa>(.*?)<\/placa>/', $output, $placa);
          $placa = $placa[1];
        }catch(Exception $e){
          $placa = "XXX0000";
        }
        
        try{
          preg_match('/<anoModelo>(.*?)<\/anoModelo>/', $output, $anoModelo);
          $anoModelo = $anoModelo[1];
        }catch(Exception $e){
          $anoModelo = "0000";
        }
        
        try{
          preg_match('/<municipio>(.*?)<\/municipio>/', $output, $municipio);
          $municipio = $municipio[1];
        }catch(Exception $e){
          $municipio = "INDEFINIDO";
        }

        $situacao = "INDEFINIDA";
        try{
          preg_match('/<situacao>(.*?)<\/situacao>/', $output, $situacao);
          $situacao = $situacao[1];
        }catch(Exception $e){
          $situacao = "INDEFINIDA";
        }

        try{
          preg_match('/<codigoSituacao>(.*?)<\/codigoSituacao>/', $output, $codigoSituacao);
          $codigoSituacao = $codigoSituacao[1];
        }catch(Exception $e){
          $codigoSituacao = "0";
        }
       
        try{
          preg_match('/<marca>(.*?)<\/marca>/', $output, $marcaOut);
          $mm = split('/', $marcaOut[1]);
          //echo $mm;
          if(count($mm) == 2){
            list($marca, $modelo) = $mm;
          }else{
            $marca = "INDEFINIDA";
            $modelo = "INDEFINIDO";
          }
        }catch(Exception $e){
          $marca = "INDEFINIDA";
          $modelo = "INDEFINIDO";
        }

        $chassi = str_replace('*', '', $chassi);

        if($marca == "I" || $marca == "IMP"){
          $marca = split(' ', $modelo)[0];
        }

        if($anoModelo == "0"){
          $anoModelo = $ano;
        }

        $json['results'] = array(
          'marca' => $marca, 
          'modelo'=>$modelo, 
          'cor'=>$cor,
          'municipio'=>$municipio,
          'uf'=>$uf,
          'ano'=>$ano,
          'modelo_ano'=>$anoModelo,
          'chassi'=>$chassi,
          'situacao'=>$situacao,
          'codigoSituacao'=>$codigoSituacao,
          'placa'=>$placa
        );
      }
    }
    curl_close($soap_do);
}
echo json_encode($json);  
//echo $output;
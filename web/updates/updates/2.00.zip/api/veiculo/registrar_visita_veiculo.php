<?php
require "../utils/session.php";
require "../utils/config_db.php";
require "../utils/log_register.php";

$json = array();
if( !isset($_POST['placa']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['placa']) ){
    $json['code'] = 9002;
    $json['error'] = "A placa do veículo não foi definida";
}else{
    if(isset($_POST['placa'])){
        $placa = $_POST['placa'];
    }else{
        $placa = null;
    }
    if(isset($_POST['unidade'])){
        $unidade = $_POST['unidade'];
    }else{
        $unidade = null;
    }
    if(isset($_POST['morador'])){
        $morador = $_POST['morador'];
    }else{
        $morador = null;
    }
    try {
        $pdo = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $s = $pdo->prepare("INSERT INTO visita_veiculo (`placa`, `unidade_visitada`, `morador`, `data_visita`) VALUES (:placa, :unidade, :morador, CURRENT_TIMESTAMP);"); 
        $s->bindParam(':placa', $placa, PDO::PARAM_STR, 200);
        $s->bindParam(':unidade', $unidade, PDO::PARAM_INT, 11);
        $s->bindParam(':morador', $morador, PDO::PARAM_INT, 11);
        $s->execute();
        $json['success'] = "Visita registrada";
        logger("Visita de veículo registrada: placa: ".$placa, null);
    }catch(PDOException $e){
        $json['code'] = $pdo->errorCode();
        $json['info'] = $pdo->errorInfo();
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
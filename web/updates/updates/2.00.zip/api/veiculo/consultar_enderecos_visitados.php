<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();
if( !isset($_POST['placa']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['placa']) ){
    $json['code'] = 6002;
    $json['error'] = "A placa do veículo não foi definida";
}else{
    try {
        $placa = $_POST['placa'];
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT DISTINCT  
                                m.id as id, 
                                m.nome as nome, 
                                m.celular as celular, 
                                m.id as morador_id,
                                u.rua as rua, 
                                u.numero as numero, 
                                u.id as unidade_id 
                                FROM `visita_veiculo` as vv
                                INNER JOIN morador as m ON vv.morador = m.id 
                                INNER JOIN unidades as u ON u.id = vv.unidade_visitada 
                                WHERE placa=:placa and morador is not NULL ");
        $stmt->execute(array(':placa' => $placa));
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 
        $json['results'] = $results;    
    }catch(PDOException $e){
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
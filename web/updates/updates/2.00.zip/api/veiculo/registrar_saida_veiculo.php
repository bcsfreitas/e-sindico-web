<?php
require "../utils/session.php";
require "../utils/config_db.php";
require "../utils/log_register.php";

$json = array();
if( !isset($_POST['placa']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['placa']) OR !isset($_POST['dataVisita']) ){
    $json['code'] = 9002;
    $json['error'] = "A placa ou data da visita do veículo não foram definidos.";
}else{
    if(isset($_POST['placa'])){
        $placa = $_POST['placa'];
    }else{
        $placa = null;
    }
    if(isset($_POST['dataVisita'])){
        $dataVisita = $_POST['dataVisita'];
    }else{
        $dataVisita = null;
    }

    try {
        $pdo = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $s = $pdo->prepare("UPDATE `dbcondominio`.`visita_veiculo` SET `data_saida` = CURRENT_TIMESTAMP WHERE placa = :placa AND data_visita = :data"); 
        $s->bindParam(':placa', $placa);
        $s->bindParam(':data', $dataVisita);
        $r = $s->execute();


        $s = $pdo->prepare("SELECT * FROM visita_veiculo WHERE placa = :placa AND data_visita = :data");
        $s->bindParam(':placa', $placa);
        $s->bindParam(':data', $dataVisita);
        $r = $s->execute();
        $results = $s->fetchAll(PDO::FETCH_ASSOC); 

        $json['success'] = "Saída registrada";
        $json['results'] = $results;
        logger("Saída de veículo registrada: placa: ".$placa, null);
    }catch(PDOException $e){
        $json['code'] = $pdo->errorCode();
        $json['info'] = $pdo->errorInfo();
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();
if( !isset($_POST['modelo']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['modelo']) ){
    $json['code'] = 6001;
    $json['error'] = "O modelo do veículo não foi definido";
}else{
    try {
        $sql = "SELECT * FROM `veiculo` WHERE `modelo` ";
        $modelo = split(' ', $_REQUEST['modelo']);
        $params = array();
        
        foreach($modelo as $i => $v){
            if( $i==0 OR $i=='0' ){
                $sql = $sql . " LIKE ? ";
            }else{
                $sql = $sql . " OR modelo LIKE ? ";
            }
            array_push($params, '%'.$v.'%');
        }

        $sql = $sql . " LIMIT 10 ";
       
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare($sql);
        $stmt->execute( $params );
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 

        // $results = array_map(function($r) {
        //    $r['descicao_modelo'] = utf8_encode( $r['descicao_modelo'] );
        //    return $r;
        // }, $results);

        $json['results'] = $results;    
    }catch(PDOException $e){
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
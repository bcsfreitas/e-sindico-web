<?php
require './src/PHPSMS/PHPSMS.php';
require './src/PHPSMS/Providers.php';

$number = "+556191617511";
$message = 'MEnsagem de Texto via SMS!! que legal!';

$phpsms = new PHPSMS\PHPSMS($number,$message, 'hersondf@gmail.com');

<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();
if( !isset($_POST['rua']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}
if( !isset($_POST['rua']) ){
    $json['code'] = 7001;
    $json['error'] = "A rua não foi definida";
}else{
    try {
        $rua = $_POST['rua'];
        $conn = new PDO("mysql:host=$servername;dbname=$db", 
            $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT DISTINCT numero, id FROM unidades where rua=:rua");
        $r = $stmt->execute(array(':rua' => $rua));

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 

        // $results = array_map(function($r) {
        //    $r['descicao_modelo'] = utf8_encode( $r['descicao_modelo'] );
        //    return $r;
        // }, $results);

        $json['results'] = $results;    
    }catch(PDOException $e){
        $json['error'] = $e->getMessage();
    }
}
echo json_encode($json);
$conn = null;
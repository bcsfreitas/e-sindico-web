<?php
require "../utils/session.php";
require "../utils/config_db.php";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$db", 
        $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT DISTINCT rua FROM unidades");
    $stmt->execute();

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 

    // $results = array_map(function($r) {
    //    $r['descicao_modelo'] = utf8_encode( $r['descicao_modelo'] );
    //    return $r;
    // }, $results);

    $json['results'] = $results;    
}catch(PDOException $e){
    $json['error'] = $e->getMessage();
}

echo json_encode($json);
$conn = null;
<?php
$release = realpath(dirname(__FILE__))."/utils/release.php";
echo file_get_contents($release);
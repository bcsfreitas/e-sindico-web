<?php
function logger($message, $cpf=null) {
    require "config_db.php";
    if($cpf==null){
        $cpf = $_SESSION['USER']['cpf'];
    }
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("INSERT INTO `dbcondiminio`.`log` (`id`, `usuario`, `mensagem`, `codigo`, `data`) VALUES (NULL, :cpf, :message, 1, CURRENT_TIMESTAMP);");
        $stmt->execute(array(':cpf' => $cpf, ':message' => $message)); 
    }catch(PDOException $e){

    }
}


<?php
if( !isset($_REQUEST['cpf']) OR !isset($_REQUEST['senha']) ){
    $_REQUEST = json_decode(file_get_contents('php://input'),true);
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$OK_SESSION = 0;
if( isset($_SESSION['CREATED']) && isset($_SESSION['USER']) ){
    if( !isset( $_SESSION['CREATED'] ) || time() - $_SESSION['CREATED'] > 1800){
        $OK_SESSION = 2;
    }else{
        $json['session']['user'] = $_SESSION['USER'];
        $json['session']['created'] = $_SESSION['CREATED'];
        if( !isset($_REQUEST['check']) ){
            $_SESSION['CREATED'] = time();
        }
        $OK_SESSION = 0;
    }
}else{
    $OK_SESSION = 1;
}

if($OK_SESSION == 1 OR $OK_SESSION == 2){
    $json = array();
    $json['code'] = 1500;
    $json['error'] = "Sua sessão expirou";
    echo json_encode($json);
    die;
}
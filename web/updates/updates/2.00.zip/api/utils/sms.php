<?php
function post_to_url($url, $data) {
   $fields = http_build_query($data);
   $post = curl_init();
   $url = $url.'?'.$fields;
   curl_setopt($post, CURLOPT_URL, $url);
   curl_setopt($post, CURLOPT_POST, 1);
   curl_setopt($post, CURLOPT_POSTFIELDS, $fields);
   $result = curl_exec($post);
   if($result == false){
       die('Curl error: ' . curl_error($post));
   }
   curl_close($post);
}

$url = "https://sms.comtele.com.br/Api/1e5c373d-dcfe-4ee8-85ea-b26dea86c996/SendMessage";
$content = "Jardins dos Tinguis informa: Existe uma nova correspondência lhe aguardando na portaria do condomínio. Data: ".date("d/m/y H:i");
$numero = "6191617511";

$data = array(
  'content' => $content,
  'sender' => '0618495001',
  'receivers' => $numero
);

post_to_url($url, $data);
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "dbcondiminio";
$json = array();

try{
  $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $json['message'] = "Connected successfully"; 
  $json['status'] = true;
}catch(PDOException $e){
    $json['error'] = $e->getMessage();
    $json['status'] = false;
}

echo json_encode($json);
$conn = null;
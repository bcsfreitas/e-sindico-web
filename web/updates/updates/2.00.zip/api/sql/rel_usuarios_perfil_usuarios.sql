-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 22-Maio-2015 às 18:34
-- Versão do servidor: 5.5.36
-- PHP Version: 5.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbcondiminio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `rel_usuarios_perfil_usuarios`
--

CREATE TABLE IF NOT EXISTS `rel_usuarios_perfil_usuarios` ( 
	constraint `id` primary key (`id_perfil_usuario`, `id_usuario`),  
	`id_usuario` int(11) NOT NULL, 
	`id_perfil_usuario` int(11) NOT NULL, 
	FOREIGN KEY (`id_perfil_usuario`) REFERENCES `perfil_usuarios`(id), 
	FOREIGN KEY (`id_usuario`) REFERENCES `usuarios`(id) ) 
ENGINE=InnoDB

--
-- Extraindo dados da tabela `rel_usuarios_perfil_usuarios`
--

INSERT INTO `rel_usuarios_perfil_usuarios` (`id_usuario`, `id_perfil_usuario`) VALUES
(1, 1),
(1, 1),
(1, 1),
(1, 1),
(1, 1),
(1, 1);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `rel_usuarios_perfil_usuarios`
--
ALTER TABLE `rel_usuarios_perfil_usuarios`
  ADD CONSTRAINT `rel_usuarios_perfil_usuarios_ibfk_2` FOREIGN KEY (`id_perfil_usuario`) REFERENCES `perfil_usuarios` (`id`),
  ADD CONSTRAINT `rel_usuarios_perfil_usuarios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

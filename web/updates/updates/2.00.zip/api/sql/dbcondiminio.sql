-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 26-Jun-2015 às 19:05
-- Versão do servidor: 5.5.36
-- PHP Version: 5.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbcondiminio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `condominio`
--

CREATE TABLE IF NOT EXISTS `condominio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `logradouro_base` varchar(200) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `uf` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `condominio`
--

INSERT INTO `condominio` (`id`, `nome`, `logradouro_base`, `cidade`, `bairro`, `uf`) VALUES
(1, 'Jardins dos Tinguis', 'Quadra Qc 4', 'São Sebastião', 'jardins Mangueiral', 'DF');

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` int(11) NOT NULL,
  `mensagem` varchar(255) NOT NULL,
  `codigo` int(11) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

--
-- Extraindo dados da tabela `log`
--

INSERT INTO `log` (`id`, `usuario`, `mensagem`, `codigo`, `data`) VALUES
(4, 1407374133, 'Logou no sistema', 1, '2015-05-28 14:56:49'),
(5, 1407374133, 'Logou no sistema', 1, '2015-05-28 14:59:53'),
(6, 1407374133, 'Logou no sistema', 1, '2015-05-28 15:05:23'),
(7, 1407374133, 'Logou no sistema', 1, '2015-05-28 15:13:34'),
(8, 1407374133, 'Logou no sistema', 1, '2015-05-28 15:14:14'),
(9, 1407374133, 'Logou no sistema', 1, '2015-05-28 15:14:18'),
(10, 1407374133, 'Logou no sistema', 1, '2015-05-28 18:13:30'),
(11, 1407374133, 'Logou no sistema', 1, '2015-05-28 18:27:12'),
(12, 1407374133, 'Logou no sistema', 1, '2015-05-28 18:28:25'),
(13, 1407374133, 'Logou no sistema', 1, '2015-05-28 18:29:34'),
(14, 1407374133, 'Logou no sistema', 1, '2015-05-28 18:33:57'),
(15, 1407374133, 'RenovaÃ§Ã£o de SessÃ£o', 2020, '2015-05-28 18:34:42'),
(16, 1407374133, 'RenovaÃ§Ã£o de SessÃ£o', 2020, '2015-05-28 18:34:45'),
(17, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:12:37'),
(18, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:17:14'),
(19, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:33:32'),
(20, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:40:35'),
(21, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:50:13'),
(22, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:52:15'),
(23, 1407374133, 'Logou no sistema', 1, '2015-05-28 19:59:06'),
(24, 1407374133, 'Logou no sistema', 1, '2015-05-28 20:16:15'),
(25, 1407374133, 'Logou no sistema', 1, '2015-05-29 16:08:48'),
(26, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:19:17'),
(27, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:22:30'),
(28, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:33:13'),
(29, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:33:16'),
(30, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:33:43'),
(31, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:35:46'),
(32, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:36:33'),
(33, 1407374133, 'Logou no sistema', 1, '2015-05-29 17:37:05'),
(34, 1407374133, 'Logou no sistema', 1, '2015-06-02 12:59:45'),
(44, 1407374133, 'Logou no sistema', 1, '2015-06-02 16:43:48'),
(45, 1407374133, 'Tentativa de login invÃ¡lida', 1, '2015-06-02 16:46:13'),
(48, 1407374133, 'Tentativa de login invÃ¡lida', 1, '2015-06-02 16:47:57'),
(49, 1407374133, 'Tentativa de login invÃ¡lida', 1, '2015-06-02 16:48:46'),
(50, 1407374133, 'Logou no sistema', 1, '2015-06-02 16:48:56'),
(51, 1407374133, 'Tentativa de login invÃ¡lida', 1, '2015-06-03 13:17:30'),
(52, 1407374133, 'Tentativa de login invÃ¡lida', 1, '2015-06-03 13:17:58'),
(53, 1407374133, 'Logou no sistema', 1, '2015-06-03 14:56:55'),
(54, 1407374133, 'Logou no sistema', 1, '2015-06-03 16:07:00'),
(55, 1407374133, 'Logou no sistema', 1, '2015-06-05 12:35:51'),
(56, 1407374133, 'Logou no sistema', 1, '2015-06-11 13:46:24'),
(57, 1407374133, 'Logou no sistema', 1, '2015-06-11 17:11:56'),
(58, 1407374133, 'Logou no sistema', 1, '2015-06-11 17:17:46'),
(59, 1407374133, 'Logou no sistema', 1, '2015-06-16 12:25:51'),
(60, 1407374133, 'Logou no sistema', 1, '2015-06-16 16:07:56'),
(61, 1407374133, 'Logou no sistema', 1, '2015-06-18 14:18:34'),
(62, 1407374133, 'Logou no sistema', 1, '2015-06-18 16:08:05'),
(64, 1407374133, 'Logou no sistema', 1, '2015-06-18 18:46:50'),
(65, 1407374133, 'Logou no sistema', 1, '2015-06-18 19:43:08'),
(66, 1407374133, 'Logou no sistema', 1, '2015-06-18 19:43:10'),
(67, 1407374133, 'Logou no sistema', 1, '2015-06-22 16:20:28'),
(68, 1407374133, 'Logou no sistema', 1, '2015-06-22 21:53:52'),
(69, 1407374133, 'Logou no sistema', 1, '2015-06-23 13:20:18'),
(70, 1407374133, 'Logou no sistema', 1, '2015-06-23 17:58:56'),
(71, 1407374133, 'Logou no sistema', 1, '2015-06-23 18:26:29'),
(72, 1407374133, 'Logou no sistema', 1, '2015-06-24 13:15:48'),
(73, 1407374133, 'Logou no sistema', 1, '2015-06-24 14:01:18'),
(74, 1407374133, 'Logou no sistema', 1, '2015-06-24 15:55:33'),
(75, 1407374133, 'Logou no sistema', 1, '2015-06-24 16:16:47'),
(76, 1407374133, 'Logou no sistema', 1, '2015-06-24 19:41:19'),
(77, 1407374133, 'Logou no sistema', 1, '2015-06-25 17:29:47'),
(78, 1407374133, 'Visita de veÃ­culo registrada: placa: JHL4985', 1, '2015-06-25 17:34:52'),
(79, 1407374133, 'Visita de veÃ­culo registrada: placa: JHL4985', 1, '2015-06-25 17:35:59'),
(80, 1407374133, 'Visita de veÃ­culo registrada: placa: jhl4985', 1, '2015-06-25 17:46:53'),
(81, 1407374133, 'Visita de veÃ­culo registrada: placa: JHL4985', 1, '2015-06-25 17:47:22'),
(82, 1407374133, 'Visita de veÃ­culo registrada: placa: JHL4985', 1, '2015-06-25 17:47:47'),
(83, 1407374133, 'Logou no sistema', 1, '2015-06-25 18:34:18'),
(84, 1407374133, 'Logou no sistema', 1, '2015-06-26 12:51:54'),
(85, 1407374133, 'Logou no sistema', 1, '2015-06-26 16:53:36');

-- --------------------------------------------------------

--
-- Estrutura da tabela `morador`
--

CREATE TABLE IF NOT EXISTS `morador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` int(11) DEFAULT NULL,
  `nome` varchar(255) NOT NULL,
  `id_unidade` int(11) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dt_nascimento` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_unidade` (`id_unidade`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `morador`
--

INSERT INTO `morador` (`id`, `cpf`, `nome`, `id_unidade`, `celular`, `email`, `dt_nascimento`) VALUES
(1, 1407374133, 'Herson Rodrigues Santos', 1, '6191617511', 'hersondf@gmail.com', '1987-04-14'),
(2, NULL, 'Suzane da Costa', 2, '6193258475', 'suza.ne@gmail.com', '0000-00-00'),
(7, NULL, 'Sintia Anne Silva', 2, '', '', '1987-04-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `perfil_usuarios`
--

CREATE TABLE IF NOT EXISTS `perfil_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `descricao` tinytext NOT NULL,
  `permissao` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Extraindo dados da tabela `perfil_usuarios`
--

INSERT INTO `perfil_usuarios` (`id`, `nome`, `descricao`, `permissao`) VALUES
(1, 'Logar no Sistema', 'Com este perfil o usuário poderá somente efetuar login no sistema.', 'logar'),
(2, 'Cadastrar Unidades', 'Com este perfil, o usuário poderá cadastrar novas unidade', 'add_unidades'),
(3, 'Alterar Unidades', 'Com este perfil o usuário poderá, alterar informações de unidades.', 'edit_unidades'),
(4, 'Excluir Unidades', 'Com este perfil o usuário poderá, excluir informações de unidades.', 'del_unidades'),
(5, 'Listar Unidades', 'Com este perfil o usuário poderá, listar todas as unidades.', 'list_unidades'),
(6, 'Relatório de Unidades', 'Com este perfil, o usuário poderá gerar relatórios das unidades', 'report_unidades');

-- --------------------------------------------------------

--
-- Estrutura da tabela `rel_usuarios_perfil_usuarios`
--

CREATE TABLE IF NOT EXISTS `rel_usuarios_perfil_usuarios` (
  `id_usuario` int(11) NOT NULL,
  `id_perfil_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_perfil_usuario`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `rel_usuarios_perfil_usuarios`
--

INSERT INTO `rel_usuarios_perfil_usuarios` (`id_usuario`, `id_perfil_usuario`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_unidade`
--

CREATE TABLE IF NOT EXISTS `tipo_unidade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `icone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `tipo_unidade`
--

INSERT INTO `tipo_unidade` (`id`, `nome`, `icone`) VALUES
(1, 'Casa', 'fa fa-home'),
(2, 'Apartamento', 'fa fa-building-o');

-- --------------------------------------------------------

--
-- Estrutura da tabela `unidades`
--

CREATE TABLE IF NOT EXISTS `unidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logradouro` varchar(200) DEFAULT NULL,
  `numero` varchar(50) NOT NULL,
  `cep` varchar(8) DEFAULT NULL,
  `rua` varchar(10) DEFAULT NULL,
  `tipo` int(11) NOT NULL,
  `proprietario` int(11) DEFAULT NULL,
  `data_cadatro` timestamp NULL DEFAULT NULL,
  `data_alteracao` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `unidades`
--

INSERT INTO `unidades` (`id`, `logradouro`, `numero`, `cep`, `rua`, `tipo`, `proprietario`, `data_cadatro`, `data_alteracao`) VALUES
(1, '', '11', '71699170', 'E', 1, NULL, NULL, NULL),
(2, NULL, '9', NULL, 'E', 1, NULL, NULL, NULL),
(3, NULL, '13', NULL, 'E', 1, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `senha` varchar(32) NOT NULL,
  `id_morador` int(11) DEFAULT NULL,
  `caminho_foto` varchar(255) DEFAULT NULL,
  `data_cadastro` timestamp NULL DEFAULT NULL,
  `data_alteracao` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data_ultimo_login` timestamp NULL DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `id_morador` (`id_morador`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `cpf`, `nome`, `email`, `senha`, `id_morador`, `caminho_foto`, `data_cadastro`, `data_alteracao`, `data_ultimo_login`, `ativo`) VALUES
(1, 1407374133, 'Herson Rodrigues Santos', 'hersondf@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, NULL, '2015-05-28 15:25:50', '0000-00-00 00:00:00', 1),
(15, 1407374136, 'Maria da Silva', 'maria@silva.com', 'e10adc3949ba59abbe56e057f20f883e', 1, NULL, '2015-06-03 20:12:27', '2015-06-03 20:12:27', '2015-06-03 20:12:27', 1),
(16, 1407374139, 'Rafael', 'rafael@rr.com.br', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, '2015-06-03 20:23:09', '2015-06-03 20:23:09', '2015-06-03 20:23:09', 1),
(17, 2147483647, 'Socorro do Carmo', 'socorro@xpto.com', '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '2015-06-03 20:43:52', '2015-06-03 20:43:52', '2015-06-03 20:43:52', 1),
(19, 1407374199, 'Rita Cadilac', 'ritinha@cadilac.com', 'ca23c900998654564673664954937711', NULL, NULL, '2015-06-03 20:44:53', '2015-06-03 20:44:53', '2015-06-03 20:44:53', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `veiculo`
--

CREATE TABLE IF NOT EXISTS `veiculo` (
  `placa` varchar(7) NOT NULL,
  `marca` varchar(200) DEFAULT NULL,
  `modelo` varchar(200) DEFAULT NULL,
  `cor` varchar(80) DEFAULT NULL,
  `chassi_final` varchar(10) DEFAULT NULL,
  `ano` varchar(4) DEFAULT NULL,
  `modelo_ano` varchar(4) DEFAULT NULL,
  `municipio` varchar(200) DEFAULT NULL,
  `uf` varchar(2) DEFAULT NULL,
  `renavam` varchar(40) DEFAULT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`placa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `veiculo`
--

INSERT INTO `veiculo` (`placa`, `marca`, `modelo`, `cor`, `chassi_final`, `ano`, `modelo_ano`, `municipio`, `uf`, `renavam`, `data_cadastro`) VALUES
('JHL4985', 'VW', 'FOX 1.6 PLUS', 'PRETA', '02357', '2007', '2008', NULL, NULL, NULL, '2015-06-24 12:26:56'),
('JIQ4170', 'GM', 'ASTRA HB 4P ADVANTAGE', 'VERMELHA', '22083', '2011', '2011', NULL, NULL, NULL, '2015-06-23 13:54:12'),
('JIQ4171', 'HONDA', 'NXR150 BROS ES', 'PRETA', '54469', '2011', '2011', NULL, NULL, NULL, '2015-06-24 13:00:31'),
('JIQ4172', 'VW', 'GOL 1.0', 'PRETA', '72895', '2011', '2011', 'BRASILIA', 'DF', NULL, '2015-06-24 13:03:20'),
('JIQ4175', 'FIAT', 'SIENA EL FLEX', 'PRETA', '43534', '2009', '2010', 'BRASILIA', 'DF', NULL, '2015-06-24 13:06:43');

-- --------------------------------------------------------

--
-- Estrutura da tabela `visita_veiculo`
--

CREATE TABLE IF NOT EXISTS `visita_veiculo` (
  `placa` varchar(7) NOT NULL,
  `unidade_visitada` int(11) NOT NULL,
  `morador` int(11) DEFAULT NULL,
  `data_visita` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `unidade_visitada` (`unidade_visitada`),
  KEY `morador` (`morador`),
  KEY `unidade_visitada_2` (`unidade_visitada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `visita_veiculo`
--

INSERT INTO `visita_veiculo` (`placa`, `unidade_visitada`, `morador`, `data_visita`) VALUES
('JIQ4170', 1, 0, '2015-06-23 20:02:54'),
('JIQ4170', 1, 1407374133, '2015-06-23 20:03:24'),
('JIQ4170', 1, NULL, '2015-06-23 20:09:53'),
('JIQ4170', 1, 1, '2015-06-23 20:13:41'),
('JIQ4170', 1, 1, '2015-06-23 20:14:40'),
('JIQ4170', 1, 1, '2015-06-23 20:14:46'),
('JIQ4173', 1, 1, '2015-06-24 13:30:54'),
('JIQ4173', 1, 1, '2015-06-24 13:31:07'),
('JIQ4173', 2, 2, '2015-06-24 13:42:25'),
('JIQ4170', 1, 1, '2015-06-24 16:27:14'),
('jiq4175', 2, 2, '2015-06-24 19:45:32'),
('jiq4175', 1, 1, '2015-06-24 19:50:40'),
('JIQ4175', 11, 1, '2015-06-24 19:58:06'),
('JIQ4175', 11, 1, '2015-06-24 19:59:18'),
('JIQ4175', 11, 1, '2015-06-24 20:05:48'),
('JIQ4175', 11, 1, '2015-06-24 20:07:29'),
('JIQ4175', 11, 1, '2015-06-24 20:08:27'),
('JIQ4175', 11, 1, '2015-06-24 20:11:27'),
('JIQ4175', 11, 1, '2015-06-24 20:13:42'),
('JIQ4170', 2, 2, '2015-06-24 20:15:22'),
('JIQ4175', 1, 1, '2015-06-24 20:33:44'),
('JIQ4175', 11, 1, '2015-06-24 20:39:59'),
('JIQ4175', 11, 1, '2015-06-24 20:41:31'),
('JIQ4175', 11, 1, '2015-06-24 20:42:28'),
('JIQ4175', 2, 2, '2015-06-24 21:19:11'),
('JIQ4170', 11, 1, '2015-06-24 21:19:35'),
('JIQ4175', 11, 1, '2015-06-24 21:29:02'),
('JIQ4175', 1, 1, '2015-06-24 21:35:36'),
('JIQ4175', 1, NULL, '2015-06-24 21:36:53'),
('JIQ4175', 2, NULL, '2015-06-24 21:45:29'),
('JIQ4175', 2, 2, '2015-06-24 21:46:52'),
('JHL4985', 1, 1, '2015-06-25 17:34:51'),
('JHL4985', 1, NULL, '2015-06-25 17:35:58'),
('jhl4985', 1, 1, '2015-06-25 17:46:52'),
('JHL4985', 1, 1, '2015-06-25 17:47:21'),
('JHL4985', 2, 2, '2015-06-25 17:47:46');

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`cpf`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `morador`
--
ALTER TABLE `morador`
  ADD CONSTRAINT `morador_ibfk_1` FOREIGN KEY (`id_unidade`) REFERENCES `unidades` (`id`);

--
-- Limitadores para a tabela `rel_usuarios_perfil_usuarios`
--
ALTER TABLE `rel_usuarios_perfil_usuarios`
  ADD CONSTRAINT `rel_usuarios_perfil_usuarios_ibfk_1` FOREIGN KEY (`id_perfil_usuario`) REFERENCES `perfil_usuarios` (`id`),
  ADD CONSTRAINT `rel_usuarios_perfil_usuarios_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Limitadores para a tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_morador`) REFERENCES `morador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

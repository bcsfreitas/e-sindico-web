<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();

$_POST = json_decode(file_get_contents('php://input'),true);

if( !isset($_POST ) ){
    $json['code'] = 1340;
    $json['error'] = "As informações não estão completas";
}else{
    if(isset($_POST['nome'])){
        $nome = $_POST['nome'];
    }else{
        $nome = null;
    }
    if(isset($_POST['cpf'])){
        $cpf = $_POST['cpf'];
    }else{
        $cpf = null;
    } 
    if(isset($_POST['email'])){
        $email = $_POST['email'];
    }else{
        $email = null;
    }         
    if(isset($_POST['senha'])){
        $senha = md5($_POST['senha']);
    }else{
        $senha = null;
    } 
    if(isset($_POST['ativo'])){
        $ativo = $_POST['ativo'];
    }else{
        $ativo = null;
    }    
    if(isset($_POST['perfil'])){
        $perfil = $_POST['perfil'];
    }else{
        $perfil = null;
    }
    if(isset($_POST['isMorador']) && isset($_POST['morador'])){
        $idMorador = $_POST['morador']['id'];
    }else{
        $idMorador = null;
    }
    if(isset($_POST['foto'])){
        $foto = $_POST['foto'];
    }else{
        $foto = null;
    }

    try {
        $pdo = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $s = $pdo->prepare("INSERT INTO `dbcondiminio`.`usuarios` (`id`, `cpf`, `nome`, `email`, `senha`, `id_morador`, `caminho_foto`, `data_cadastro`, `data_alteracao`, `data_ultimo_login`, `ativo`) VALUES (NULL, :cpf, :nome, :email, :senha, :idMorador, :foto, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :ativo);"); 
        $s->bindParam(':cpf', $cpf, PDO::PARAM_INT, 11);
        $s->bindParam(':nome', $nome, PDO::PARAM_STR, 200);
        $s->bindParam(':email', $email, PDO::PARAM_STR, 200);
        $s->bindParam(':senha', $senha, PDO::PARAM_STR, 32);
        $s->bindParam(':idMorador', $idMorador, PDO::PARAM_INT, 11);
        $s->bindParam(':foto', $foto, PDO::PARAM_STR, 255);
        $s->bindParam(':ativo', $ativo, PDO::PARAM_INT, 1);
        $s->execute();
        $json['success'] = "Usuário adicionado";
    }catch(PDOException $e){
        $json['code'] = $pdo->errorCode();
        $json['info'] = $pdo->errorInfo();
        $json['error'] = $e->getMessage();
    }

}

echo json_encode($json);
$conn = null;
<?php
require "../utils/session.php";
require "../utils/config_db.php";

$json = array();

// for angular JSON params
if( !isset($_POST['cpf']) ){
    $_POST = json_decode(file_get_contents('php://input'),true);
}

if( !isset($_POST['cpf']) ){
    $json['code'] = 1650;
    $json['error'] = "O cpf não foi definido.";
}else{
    $cpf = $_POST['cpf'];

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT nome FROM usuarios WHERE cpf=:cpf");
        $stmt->execute(array(':cpf' => $cpf)); 

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC); 

        $results = array_map(function($r) {
             $r['nome'] = utf8_encode( $r['nome'] );
             return $r;
        }, $results);

        $json['results'] = $results;
        
    }catch(PDOException $e){
        $json['error'] = $e->getMessage();
    }
}

echo json_encode($json);
$conn = null;
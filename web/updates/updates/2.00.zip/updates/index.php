<h1>Atualização Dinâmica do Sistema</h1>
<?
ini_set('max_execution_time',60);
$release = realpath(dirname(__FILE__))."/release.php";
$localDir = realpath(dirname(__FILE__))."/";
$localRootDir = "C:/xampp/htdocs/ex9Condominio";
$currentRelease = file_get_contents($release);
$urlReadReleases = 'http://127.0.0.1/testeUpdate/updates/release.php';
$urlUpdates = 'http://127.0.0.1/testeUpdate/updates';


//Check for an update. We have a simple file that has a new release version on each line. (1.00, 1.02, 1.03, etc.)
$getVersions = file_get_contents($urlReadReleases) or die ('ERROR');
if ($getVersions != '')
{
    //If we managed to access that file, then lets break up those release versions into an array.
    echo '<p>VERSÃO ATUAL: '.$currentRelease.'</p>';
    echo '<p>Reading Current Releases List</p>';
    $versionList = explode("n", $getVersions);    
    foreach ($versionList as $aV)
    {
        if ( $aV > get_siteInfo('CMS-Version')) {
            echo '<p>Nova versão encontrada: v'.$aV.'</p>';
            $found = true;
           
            //Download The File If We Do Not Have It
            if ( !is_file(  $urlUpdates.'/'.$aV.'.zip' ) ) {
                echo '<p>Baixando nova atualização...</p>';
                $newUpdate = file_get_contents( $urlUpdates.'/'.$aV.'.zip' );
                if ( !is_dir( $localDir ) ) mkdir ( $localDir );
                $dlHandler = fopen( $localDir.'/'.$aV.'.zip' , 'w');
                if ( !fwrite($dlHandler, $newUpdate) ) { echo '<p> Não foi possível salvar no diretório, opreação cancelada.</p>'; exit(); }
                fclose($dlHandler);
                echo '<p>Download da Atualização foi salvo.</p>';
            } else echo '<p>Atualização ainda está baixando...</p>';    
           
            if ($_GET['doUpdate'] == true) {
                //Open The File And Do Stuff
                $zipHandle = zip_open( $localDir.'/'.$aV.'.zip' );
                echo '<ul>';
                while ($aF = zip_read($zipHandle) )
                {
                    $thisFileName = zip_entry_name($aF);
                    $thisFileDir = dirname($thisFileName);
                   
                    //Continue if its not a file
                    if ( substr($thisFileName,-1,1) == '/') continue;
                   
    
                    //Make the directory if we need to...
                    if ( !is_dir ( $localRootDir.'/'.$thisFileDir ) )
                    {
                         mkdir ( $localRootDir.'/'.$thisFileDir );
                         echo '<li>Created Directory '.$thisFileDir.'</li>';
                    }
                   
                    //Overwrite the file
                    if ( !is_dir($localRootDir.'/'.$thisFileName) ) {
                        echo '<li>'.$thisFileName.'...........';
                        $contents = zip_entry_read($aF, zip_entry_filesize($aF));
                        $contents = str_replace("rn", "n", $contents);
                        $updateThis = '';
                       
                        //If we need to run commands, then do it.
                        if ( $thisFileName == 'upgrade.php' )
                        {
                            $upgradeExec = fopen ('upgrade.php','w');
                            fwrite($upgradeExec, $contents);
                            fclose($upgradeExec);
                            include ('upgrade.php');
                            unlink('upgrade.php');
                            echo' EXECUTADO</li>';
                        }
                        else
                        {
                            $updateThis = fopen($localRootDir.'/'.$thisFileName, 'w');
                            fwrite($updateThis, $contents);
                            fclose($updateThis);
                            unset($contents);
                            echo' ATUALIZADO</li>';
                        }
                    }
                }
                echo '</ul>';
                $updated = TRUE;
            }
            else echo '<p>Atualização pronta. <a href="?doUpdate=true">&raquo; DESEJA INSTALAR AGORA?</a></p>';
            break;
        }
    }
    
    if ($updated == true)
    {
        set_setting('site','CMS',$aV);
        echo '<p class="success">&raquo; Sistema atualizado para a vesão: '.$aV.'</p>';
    }
    else if ($found != true) echo '<p>&raquo; Nova atualização disnponível.</p>';

    
}
else echo '<p>Você está com a versão mais atualizada.</p>';
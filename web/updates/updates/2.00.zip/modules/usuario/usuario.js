(function() {

	app.controller('usuarioAddCtrl', ['$scope', '$http', '$timeout', '$modal', function ($scope, $http, $timeout, $modal) {
		$scope.user = {};
		$scope.perfilUsuarios = [];
		$scope.moradores = [];
		$scope.httpGetPerfilUsuarios = function(){
			$http.get('api/usuario/lista_perfil_usuarios.php').success(function(data){
				$scope.perfilUsuarios = data.results;
				$scope.perfilUsuariosList = [];
				angular.forEach($scope.perfilUsuarios, function(i){
					$scope.perfilUsuariosList.push(i.id)
				});
			});
		};
		$scope.httpGetPerfilUsuarios();
		$scope.validaUsuario = function(){
			$timeout(function(){
				$http({ withCredentials: false, method: 'post', url: 'api/usuario/verifica_usuario_existente.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:$scope.user }).success(function(data){
					if(data && data.results && data.results.length>0){
						$scope.usuarioExistente = data.results[0].nome;
					}
				});
			}, 500);
		};
		$scope.listaMoradores = function(){
			$timeout(function(){
				$http({ withCredentials: false, method: 'post', url: 'api/morador/lista_morador.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).success(function(data){
					if(data && data.results && data.results.length>0){
						$scope.moradores = data.results;
						$scope.morador = $scope.moradores[0];
					}
				});
			}, 500);
		};
		$scope.adicionar = function(){
			$scope.error = null;
			$scope.spin = true;
			$http({ withCredentials: false, method: 'post', url: 'api/usuario/cadastro.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:$scope.user})
			.then(function(response) {
				console.log('Resposta do Adicionar',response)
				if(response.error){
					$scope.error = response.error;
				}else if(response.data.success){
					$scope.openModal();
					//$state.go('app.usuario');
				}else{
					$scope.error = response.data;
				}
				$scope.spin = false;
			}, function(error) {
				$scope.error = 'Erro ao tentar efetuar o cadastro do usuário.';
				$scope.completeError = error;
				$scope.spin = false;
			});
		};
		$scope.openModal = function(){
			var modalInstance = $modal.open({
			  animation: true,
			  templateUrl: 'modalConfirm.html',
			  controller: 'openModalCtrl',
			  size: 'lg',
			});
		};
	}]);

	app.controller('openModalCtrl', function ($scope, $modalInstance) {

	});

	app.controller('usuarioListCtrl', ['$scope', '$http', function ($scope, $http) {
		$scope.lista = null;
		$scope.error = null;
		$http.post('api/usuario/lista_usuarios.php')
		.then(function(response) {
			if (response.data.results) {
			  $scope.listaUsuarios = response.data.results;
			}else{
			  $scope.error = "Não foi possível recuperar a lista de usuários.";
			}
		}, function(message) {
			$scope.error =  "Não foi possível lista os usuários. Error: " + String(message);
		});	
	}]);

	app.directive('modalOption', function() {
  		return {
  			restrict: 'E',
  			scope: {
      			label: '@',
      			url:'@',
      			icon:'@',
      			key:'@',
      			laba:'@',
      			labb:'@',
      			cola:'@',
      			colb:'@',
      			ngModel:'=',
    		},
    		templateUrl: "./modules/usuario/modalOption.html",
    		controller:'modalOptionCtrl',
  		};
	});
	app.controller('modalOptionCtrl', ['$scope', '$http', '$modal', function ($scope, $http, $modal) {
		$scope.items = $scope.ngModel;
		$scope.open = function(){
			var m = $modal.open({
		  		animation: true,
		  		templateUrl: 'modalOption.html',
		  		controller: function($scope, $modalInstance, label, ngModel, key, url, cola, colb, laba, labb){
		  			//@params (attrs)
		  			$scope.ngModel = ngModel;
		  			$scope.label = label;
		  			$scope.key = key;
		  			$scope.url = url;
		  			$scope.cola = cola;
		  			$scope.colb = colb || undefined,
		  			$scope.laba = laba;
		  			$scope.labb = labb || undefined;

		  			$scope.modalClosed = false;
		  			$scope.spin = true;
		  			$http.get($scope.url).success(function(data){
						$scope.defaultItems = data;
						$scope.spin = false;
					});
					$scope.$watch('defaultItems', function(o,n){
						if(o !== n){
							$scope.items = $scope.merge(o[$scope.key], $scope.ngModel);
						}
					});
					$scope.merge = function(i1, i2){
						var n = [];
						angular.forEach(i1, function(i){
		  					angular.forEach(i2, function(d){
		  						if(i.id == d.id){
		  							if(i.ckeck==true){
		  								i.ckeck = false;
		  							}else{
		  								i.ckeck = true;
		  							}
		  						}
		  					});
		  					n.push(i);
		  				});
		  				return n;
					};
					
		  			$scope.ckeck = function(bool){
		  				angular.forEach($scope.items, function(i){
		  					i.ckeck = bool;
		  				});
		  			};
		  			$scope.mark = function(itemsToMark, btn){
		  				angular.forEach($scope.items, function(item){
		  					angular.forEach(itemsToMark, function(mark){
		  						if(item.id == mark){
		  							if(item.ckeck==true){
		  								item.ckeck = false;
		  							}else{
		  								item.ckeck = true;
		  							}
		  						}
		  					});
		  				});
		  			};
		  			$scope.close = function(){
		  				var selectedItems = [];
		  				angular.forEach($scope.items, function(item){
		  					if(item.ckeck == true){
		  						selectedItems.push(item);
		  					}
		  				})
		  				$scope.items = selectedItems;
		  				$modalInstance.close($scope.items);
		  			};
		  		},
		  		size: 'lg',
		  		resolve: {
        			label: function(){
          				return $scope.label;
        			},
        			url: function(){
        				return $scope.url;
        			},
        			key: function(){
        				return $scope.key;
        			},
        			cola: function(){
        				return $scope.cola;
        			},
        			colb: function(){
        				return $scope.colb;
        			},
        			laba: function(){
        				return $scope.laba;
        			},
        			labb: function(){
        				return $scope.labb;
        			},
        			items: function(){
        				return $scope.items;
        			},
        			ngModel: function(){
        				return $scope.ngModel;
        			}
      			}
			});

			m.result.then(function (selectedItems) {
			      $scope.ngModel = selectedItems;
			      $scope.modalClosed = true;
			    }, function () {
			      console.info('Modal dismissed at: ' + new Date());
		    	}
		    );
		};
	}]);
})();
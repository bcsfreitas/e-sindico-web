(function() {
	app.controller('signinCtrl', ['$scope', '$rootScope', '$http', '$state', function ($scope, $rootScope, $http, $state) {
		$scope.authError = null;
		$scope.spin = false;
		if($state.params.errorCode==1500){
			$scope.$emit('ex9SessionExpired');
			$scope.authError = "Devido a sua inatividade, sua sessão expirou.";
		}
		$scope.user = {};	    
	    $scope.login = function() {
	      $scope.spin = true;
	      $scope.authError = null;
	      // Try to login
	      $http({ withCredentials: false, method: 'post', url: 'api/acesso/login.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data: {cpf: $scope.user.cpf, senha: $scope.user.pass} })
	      .then(function(response) {
	      	if(response.data && response.data.code && response.data.code==1001){
	      		$scope.authError = "Não foi possível acessar o sistema, verifique o usuário e senha."
	      	}else if(response.data.results){
	          $rootScope.app.user = response.data.results[0];
	          $state.go('app.usuario');
	        }else{
	        	$scope.authError = response.data.error;
	        }
	        $scope.spin = false;
	      }, function(x) {
	        $scope.authError = 'Erro ao tentar efetuar o login do usuário.';
	        $scope.completeError = str(x);
	        $scope.spin = false;
	      });
	    };
	}]);

	app.controller('lockCtrl', ['$scope', '$http', '$state', function ($scope, $http, $state) {
		
	    
	}]);

})();
(function() {
	app.controller('veiculo', ['$scope', function ($scope) {
		
	}]);
	app.controller('buttons', ['$scope', '$modal', function ($scope, $modal) {
		$scope.registarVisita = function(){
			var modalInstance = $modal.open({
			  animation: true,
			  templateUrl: 'modalRegistrarVisita.html',
			  controller: 'registarVisitaCtrl',
			  size: 'lg',
			});
		};
	}]);
	app.controller('registarVisitaCtrl', ['$scope', 'focus', '$document', '$http', '$timeout', '$modalInstance', function($scope, focus, $document, $http, $timeout, $modalInstance){
		$scope.$on('ex9SessionExpired', function(e){
			$modalInstance.close();
		});
		focus('placa');
		$scope.car = {};
		$scope.carExist = false;
		$scope.consultarVeiculo = function(){
			
			$scope.enderecos = [];
			$scope.searchCar = false;
			$scope.carRoubado = false;
			$scope.error = false;

			$timeout(function(){
				$scope.sucessMessage = "";
				$scope.success = false;
			}, 5000);

			if($scope.placa.length>=7){
				
				$http({ withCredentials: false, method: 'post', url: 'api/veiculo/consultar_placa.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'placa':$scope.placa.toUpperCase()} }).success(function(data){
					$scope.searchCar = true;
					if(data && data.results){
						if(data.results.length>0){
							$scope.veiculos = [];
							$scope.car = data.results[0];
							$scope.carExist = true;
							$scope.endereco = 'new';
							$scope.consultarVisitas();
							$scope.consultarRuas();
							$scope.searchCar = false;
						}else{
							$http({ withCredentials: false, method: 'post', url: 'api/veiculo/consultar_placa_externo.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'placa':$scope.placa.toUpperCase()} }).success(function(data){
								if(data && data.results){
									$scope.car = data.results;
									$scope.carExist = true;
									$scope.endereco = 'new';
									$scope.registrarVeiculo($scope.car);
									$scope.consultarVisitas();
									$scope.consultarEnderecosPorPlaca($scope.placa);
									$scope.consultarRuas();
									$scope.searchCar = false;
								}
								if(data && data.error){
									$scope.error = data.error;
									$scope.searchCar = false;
								}
							});
						}
					}else{
						if(data.error){
							$scope.error = data.error;
							$scope.searchCar = false;
						}
					}
				});
			}else{
				$scope.error = false;
				$http({ withCredentials: false, method: 'post', url: 'api/veiculo/consultar_inicio_placa.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'placa':$scope.placa.toUpperCase()} }).success(function(data){
					if(data && data.results){
						$scope.veiculos = data.results;
					}else{
						$scope.error = data.error;
					}
				});
			}
		};
		$scope.formataData = function (data) {
			return moment(data).format('DD/MM/YYYY HH:mm')+' ('+moment(data, 'YYYY-MM-DD HH:mm').locale('pt-br').fromNow()+')';
		};
		$scope.registrarSaida = function(placa, dataVisita){
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/veiculo/registrar_saida_veiculo.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'placa':placa, 'dataVisita':dataVisita} }).success(function(data){
				if(data && data.results){
					$scope.success = true;
					$scope.sucessMessage = data.success;
					$scope.reset();
				}else{
					$scope.error = data.error;
				}
			});
		};
		$scope.selectVeiculo = function(placa){
			//placa=placa.replace(/(.*)(\d{4})/,"$1-$2");  
			$scope.placa = placa;
			$scope.$apply();
			$scope.consultarVeiculo();
		};
		$scope.procuraVeiculoPorModelo = function(){
			$scope.carExist = false;
			$scope.placa = "";
			var modelo = $scope.modelo;
			
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/veiculo/consultar_por_modelo.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'modelo':modelo} }).success(function(data){
				if(data && data.results){
					$scope.veiculos = data.results;
				}else{
					$scope.error = data.error;
				}
			});
			
		}
		$scope.registrarVeiculo = function(car){
			if(car.codigoSituacao=="1"){
				$scope.carRoubado = true;
			}
			$http({ withCredentials: false, method: 'post', url: 'api/veiculo/registrar_veiculo.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:car }).success(function(data){
				if(data && data.success){
					$scope.carSuccess = data.success;
					$timeout(function(){
						$scope.carSuccess = false;
					},4000);
				}
				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.consultarVisitas = function(){
			var placa = $scope.placa;
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/veiculo/consultar_visitas.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'placa':placa.toUpperCase()} }).success(function(data){
				if(data && data.results){
					$scope.visitas = data.results;
				}
				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.consultarEnderecosPorPlaca = function(placa){
			$scope.enderecos=[];
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/veiculo/consultar_enderecos_visitados.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'placa':placa.toUpperCase()} }).success(function(data){
				if(data && data.results){
					$scope.enderecos = data.results;
				}
				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.consultarRuas = function(){
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/unidade/consultar_ruas.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{} }).success(function(data){
				if(data && data.results){
					$scope.ruas = data.results;
				}
				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.consultarUnidadePelaRua = function(){
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/unidade/consultar_unidades_pela_rua.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'rua':$scope.rua.rua} }).success(function(data){
				if(data && data.results){
					$scope.unidades = data.results;
				}
				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.consultarMoradorPeloEndereco = function(){
			$scope.error = false;
			$http({ withCredentials: false, method: 'post', url: 'api/morador/consultar_morador_pelo_endereco.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:{'rua':$scope.rua.rua, 'unidade':$scope.unidade.numero} }).success(function(data){
				if(data && data.results){
					$scope.morador = data.results[0];
					$scope.active = true;
				}

				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.endereco = '0';
		$scope.novoEndereco = function(){
			$scope.endereco='new';
			$scope.consultarRuas();
		};
		$scope.close = function(){
			$modalInstance.close();
		};
		$scope.registrar = function(){		
			$scope.error = false;
			if($scope.endereco=='new'){
				if($scope.morador && $scope.morador.id){
					var mid = $scope.morador.id;
				}else{
					var mid = null;
				}
				if($scope.unidade && $scope.unidade.id){
					var uid = $scope.unidade.id;
				}else{
					var uid = null;
				}
				var data = {'morador':mid, 'unidade':uid, 'placa':$scope.placa.toUpperCase()};
			}else{
				var data = {'morador':$scope.end.morador_id, 'unidade':$scope.end.unidade_id, 'placa':$scope.placa.toUpperCase()};
			}
			console.log('data', data);
			$http({ withCredentials: false, method: 'post', url: 'api/veiculo/registrar_visita_veiculo.php', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, data:data }).success(function(data){
				if(data && data.success){
					$scope.success = true;
					$scope.sucessMessage = data.success;
					$scope.reset();
					$timeout(function(){
						$scope.success = false;
					}, 5000);
				}else{
					$scope.error = data;
				}
				if(data.error){
					$scope.error = data.error;
				}
			});
		};
		$scope.setEndereco = function(item){
			$scope.active = true;
			$scope.end = item;
		};
		$scope.enableButton = function(){
			if($scope.carExist && $scope.active){
				return true;
			}else{
				return false;
			}
		}
		$scope.reset = function(){
			$scope.veiculos = [];
			$scope.visitas = false;
			$scope.active = false;
			$scope.placa = "";
			$scope.modelo = "";
			$scope.ruas = {};
			$scope.unidades = {};
			$scope.morador = {};
			$scope.car = {};
			$scope.end = false;
			$scope.enedereco = false;
			$scope.rua = false;
			$scope.carExist = false;
			focus("placa");
		};
	}]);
})();
(function() {
	app.constant("CON_UNIDADE", {
		            'ruas':['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'], 
					'torres': {'A':['A1'], 'B':['B1', 'B2'], 'C':['C1', 'C2', 'C3'], 'E':['E1'], 'F':['F1'], 'I':['I1', 'I2', 'I3'], 'K':['K1'], 'L':['L1', 'L2'], },
					'endereco':{'logradouro':'Quadra QC 4', 'cidade':'São Sebastião', 'cidadeEncode':'S%E3o+Sebasti%E3o','estado':'DF', 'bairro':'Jardins Mangueiral'},
		            'maxCasas':75});

	app.controller('unidadeAddCtrl', ['$scope', '$http', 'CON_UNIDADE', function ($scope, $http, CON_UNIDADE) {
		$scope.maxCasas = CON_UNIDADE.maxCasas;
		$scope.ruas = CON_UNIDADE.ruas;
		$scope.torres = CON_UNIDADE.torres;
		$scope.$watch('tipo', function(o, n){
			if(o !== n){
				if(n == 'apt'){
					$scope.ruas = CON_UNIDADE.ruas;
				}else if(n == 'casa'){
					$scope.ruas = Object.keys(CON_UNIDADE.torres);
				}
			}
		});
		$scope.$watch('rua', function(o, n){
			if(o !== n){
				$scope.getCepByLogradouro();
			}
		});
		$scope.manualCep = false;
		$scope.defineManualCep = function(){
			$scope.manualCep  = true;
		}
		$scope.uri = function(str) {
    		return encodeURIComponent(str).replace(/[!'()]/g, escape).replace(/\*/g, "%2A").replace(/\"/g, "%22");
  		};
		$scope.getLogradouroByCep = function(){
			var cep = $scope.cep;
			if(cep){
				var query = 'select * from htmlpost where url="http://www.buscacep.correios.com.br/servicos/dnec/consultaEnderecoAction.do" and postdata="relaxation='+cep+'&TipoCep=LOG&semelhante=N&cfm=1&Metodo=listaLogradouro&TipoConsulta=relaxation&StartRow=1&EndRow=10" and xpath="//tr[contains(@bgcolor,\'#ECF3F6\')]/td"';
	      		var url = 'http://query.yahooapis.com/v1/public/yql?q=' + $scope.uri(query) + '&format=json&ie=utf-8%27%0A&callback=JSON_CALLBACK&env=http://datatables.org/alltables.env';
				$http.jsonp(url, {cache: false}).success(function(data){
					console.log('data', data)
					try{
						var field = data.query.results.postresult.td;
						var logradouro = field[0].content;
						var novaRua = logradouro[logradouro.length-1];
						if(novaRua != $scope.rua){
							if($scope.manualCep){
								if(confirm("O CEP que você informou encontrou o endereço: "+ logradouro +", a rua está diferente, deseja atualizar para novo endereço?")){
									$scope.rua = novaRua;
								}
							}else{
								$scope.rua = novaRua;
							}
						}
					}catch(err){
						console.error("Erro ao buscar cep pelo endereço: "+logradouro, err);
					}
				}).error(function(err){
					console.error("Não foi possível encontrar as informações do endereço. Erro: "+err);
				});
			}
		};
		$scope.getCepByLogradouro = function(){
			var rua = $scope.rua;
			if(rua){
				console.log('rua', rua)
				var logradouro = CON_UNIDADE.endereco.logradouro + ' Rua ' + rua +' '+ CON_UNIDADE.endereco.cidadeEncode + ' - ' +CON_UNIDADE.endereco.estado;
				logradouro = logradouro.replace(/ /g, '+' );
				console.log('logradouro', logradouro);
				var query = 'select * from htmlpost where url="http://www.buscacep.correios.com.br/servicos/dnec/consultaEnderecoAction.do" and postdata="relaxation='+logradouro+'&TipoCep=LOG&semelhante=N&cfm=1&Metodo=listaLogradouro&TipoConsulta=relaxation&StartRow=1&EndRow=10" and xpath="//tr[contains(@bgcolor,\'#ECF3F6\')]/td"';
	      		var url = 'http://query.yahooapis.com/v1/public/yql?q=' + $scope.uri(query) + '&format=json&ie=utf-8%27%0A&callback=JSON_CALLBACK&env=http://datatables.org/alltables.env';
	      		console.log(logradouro)
				$http.jsonp(url, {cache: false}).success(function(data){
					console.log('data', data)
					try{
						var cep = data.query.results.postresult.td[4].content;
						if($scope.cep && $scope.cep != cep){
							if($scope.manualCep){
								if(confirm("A Rua que você informou está diferente do CEP preenchido, deseja atualizar o campo com o novo CEP?")){
									$scope.cep = cep;
								}
							}else{
								$scope.cep = cep;
							}
						}else{
							$scope.cep = cep;
						}
						console.log('cep', $scope.cep)
					}catch(err){
						console.error("Erro ao buscar cep pelo endereço: "+logradouro, err);
					}
				}).error(function(err){
					console.error("Não foi possível encontrar as informações do cep. Erro: "+err);
				});
			}
		};
		$scope.adicionar = function(){
			//todo
		};
	}]);
})();
(function() {
    var app = angular.module('qrcodeReader', []);
	app.directive('qrcodeReader', function() {
      return {
        restrict: 'E',
        scope: {
      		ngModel:'=',
    	},
        require: 'ngModel',
        template: '<div id="qrcodereader" class="col-xs-12 col-md-12" style="height:200px;width:200px;" ng-style="style"></div>',
        controller: 'qrcodeReaderCtrl'
      };
    });
	app.controller('qrcodeReaderCtrl', ['$scope', '$timeout', function ($scope, $timeout) {
		$timeout(function(){
			$scope.screen();
		}, 500);

		$scope.screen = function(){
			var m = document.getElementById('modal');
			var w = m.offsetWidth;
			var h = m.offsetHeight;
			$scope.style = {'width':w-30+'px', 'height':h+'px', 'margin':'0 auto', 'margin-bottom':w/4+'px'};
			document.getElementsByTagName('video')[0].width = w-30;
		};

		window.onresize = function(event) {
    		$scope.screen();
		};
			
		$scope.videoError = false;
		$scope.totalError = 0;
		$scope.errorMessage = false;
		$scope.ngModel = false;
		jQuery('#qrcodereader').html5_qrcode(function(data){
		    $scope.$apply(function(){
				$scope.ngModel = data;
		    });
		    console.log('read...', data)
		}, function(error){ 
			$scope.errorMessage = error;
		    $scope.totalError = $scope.totalError + 1;
		    if($scope.totalError>100){
		    	//alert("Tente afastar mais o código da tela.");
		    	$scope.totalError = 0;
		    }
		});
		$scope.reset = function(){
			$scope.read = false;
		};
	}]);	
})();
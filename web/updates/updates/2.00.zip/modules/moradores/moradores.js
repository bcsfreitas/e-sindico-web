(function() {
	app.controller('moradoresAddCtrl', ['$scope', '$http', function ($scope, $http) {
		
	}]);


	app.controller('moradoresListCtrl', ['$scope', '$http', function ($scope, $http) {
		
	}]);
})();